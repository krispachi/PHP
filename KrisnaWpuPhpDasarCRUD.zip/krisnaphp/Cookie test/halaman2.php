<?php

echo $_COOKIE['nama'];

?>