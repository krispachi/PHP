<?php

//Membuat cookie
setcookie('nama', 'Isan');

?>