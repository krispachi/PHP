$(document).ready(function() {
    
    //menghilangkan tombol cari
    $('#tombol-cari').hide();
    
    //event ketika keyword ditulis
    $('#keyword').on('keyup', function() {
        
        $('.loader').show();
        
        //$('#container').load('ajax/mahasiswa.php?keyword=' + $('#keyword').val());
        
        $.get('ajax/mahasiswa.php?keyword=' + $('#keyword').val(), function(data) {
            
            $('#container').html(data);
            $('.loader').hide();
            
        }); 
    });
});


//    //event ketika keyword ditulis
//    $('#keyword').on('keyup', function() {
//        
//        $('#container').load('ajax/mahasiswa.php?keyword=' + $('#keyword').val());
//        
//    });