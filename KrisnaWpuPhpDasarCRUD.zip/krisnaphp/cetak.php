<?php

require_once __DIR__ . '/vendor/autoload.php';

require 'funs.php';
$mahasiswa = query("SELECT * FROM mahasiswa");

$i = 1;
$html = '<!DOCTYPE html>
<html>
<head>
    <title>Daftar Mahasiswa</title>
</head>
<body>

    <h1>DAFTAR MAHASISWA</h1>
    
    <table border="1" cellpadding="10" cellspacing="0">
    
        <tr>
            <th>No. </th>
            <th>Gambar</th>
            <th>Nrp</th>
            <th>Nama</th>
            <th>Email</th>
            <th>Jurusan</th>
        </tr>';
        
        foreach( $mahasiswa as $row ) {
            $html .= '<tr>
                <td>'. $i++ .'</td>
                <td><img src="img/'. $row["gambar"] .'" width="60"></td>
                <td>'. $row["nrp"] .'</td>
                <td>'. $row["nama"] .'</td>
                <td>'. $row["email"] .'</td>
                <td>'. $row["jurusan"] .'</td>
                
            </tr>';
        }
        
$html .= '</table>

</body>
</html>
';

$mpdf = new \Mpdf\Mpdf();
$mpdf->WriteHTML($html);
$mpdf->output('mahasiswa.pdf', 'I');










?>
